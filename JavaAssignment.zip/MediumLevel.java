
import java.io.*;

class Student implements Serializable {
    int id;
    String name;
    double gpa;

    Student(int id, String name, double gpa) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
    }
}

public class MediumLevel {
    public static void main(String[] args) {
        Student student = new Student(101, "John Doe", 3.8);

        // Serialization
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("student.ser"))) {
            out.writeObject(student);
            System.out.println("Student details saved successfully!");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Deserialization
        System.out.println("\nReading from file...");
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("student.ser"))) {
            Student readStudent = (Student) in.readObject();
            System.out.println("Student ID: " + readStudent.id);
            System.out.println("Student Name: " + readStudent.name);
            System.out.println("Student GPA: " + readStudent.gpa);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
