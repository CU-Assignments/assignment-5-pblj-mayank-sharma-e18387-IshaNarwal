
import java.util.*;

public class EasyLevel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter numbers separated by spaces: ");
        String input = scanner.nextLine();
        String[] numbers = input.split(" ");
        List<Integer> list = new ArrayList<>();
        int sum = 0;
        for (String numStr : numbers) {
            Integer num = Integer.parseInt(numStr); // Autoboxing
            list.add(num);
        }
        for (Integer num : list) {
            sum += num; // Unboxing
        }
        System.out.println("Sum of numbers: " + sum);
        scanner.close();
    }
}
